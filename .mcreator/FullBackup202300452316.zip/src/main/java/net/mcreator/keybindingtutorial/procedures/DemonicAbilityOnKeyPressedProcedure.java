package net.mcreator.keybindingtutorial.procedures;

public class DemonicAbilityOnKeyPressedProcedure {
	public static void execute() {
	}
}
